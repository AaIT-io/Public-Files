#!/bin/bash


# GOST端口转发管理脚本


# 导入包含功能函数的脚本
source /opt/gost/function.sh


# 交互式菜单
show_menu() {
    clear
    echo "====================="
    echo "GOST 端口转发管理工具"
    echo "====================="
    echo "1. 查看配置"
    echo "2. 创建转发"
    echo "3. 更新转发"
    echo "4. 删除转发"
    echo "5. 创建端口段转发"
    echo "6. 删除端口段转发"
    echo "0. 退出"
    echo "====================="
    read -p "" choice
}


# 执行用户选择的操作
execute_choice() {
    case $choice in
        1)
            clear
            echo -e
            view_config
            echo -e
            ps aux | grep "gost -L" | grep -v grep
            echo -e
            ;;
        2)
            clear
            echo "创建转发 - 注意目标地址要带端口"
            echo -e
            view_config
            echo -e
            read -p "服务名称: " service_name
            read -p "监听端口: " service_port
            read -p "目标地址: " node_addr
            if [[ -z "$service_name" && -z "$service_port" && -z "$node_addr" ]]; then
                continue  # 没有实际输入内容则跳过后面代码返回主循环
            fi
            create_service=$(create_service "$service_name" "$service_port" "$node_addr")
            create_service_save_config=$(save_config)
            echo "创建转发: $create_service"
            echo "保存配置: $create_service_save_config"
            echo -e
            view_config
            echo -e
            ;;
        3)
            clear
            echo "更新转发 - 注意目标地址要带端口"
            echo -e
            view_config
            echo -e
            read -p "服务名称: " service_name
            read -p "监听端口: " service_port
            read -p "目标地址: " node_addr
            if [[ -z "$service_name" && -z "$service_port" && -z "$node_addr" ]]; then
                continue  # 没有实际输入内容则跳过后面代码返回主循环
            fi
            update_service=$(update_service "$service_name" "$service_port" "$node_addr")
            update_service_save_config=$(save_config)
            echo "更新转发: $update_service"
            echo "保存配置: $update_service_save_config"
            echo -e
            view_config
            echo -e
            ;;
        4)
            clear
            echo "删除转发"
            echo -e
            view_config
            echo -e
            read -p "服务名称: " service_name
            if [[ -z "$service_name" ]]; then
                continue  # 没有实际输入内容则跳过后面代码返回主循环
            fi
            delete_service=$(delete_service "$service_name")
            delete_service_save_config=$(save_config)
            echo "删除转发: $delete_service"
            echo "保存配置: $delete_service_save_config"
            echo -e
            view_config
            echo -e
            ;;
        5)
            clear
            echo "创建端口段转发 - 注意目标地址不带端口"
            echo -e
            ps aux | grep "gost -L" | grep -v grep
            echo -e
            read -p "开始端口: " start_port
            read -p "结束端口: " end_port
            read -p "目标地址: " ip_addr
            if [[ -z "$start_port" && -z "$end_port" && -z "$ip_addr" ]]; then
                continue  # 没有实际输入内容则跳过后面代码返回主循环
            fi
            setsid nohup gost -L tcp://:$start_port-$end_port/$ip_addr:$start_port-$end_port >/dev/null 2>&1 &
            sleep 2s
            # 添加计划任务实现开机自启
            echo "@reboot root gost -L tcp://:${start_port}-${end_port}/${ip_addr}:${start_port}-${end_port} >/dev/null 2>&1 &" >> /etc/crontab
            echo -e
            ps aux | grep "gost -L" | grep -v grep
            ;;
        6)
            clear
            echo "删除端口段转发 - 注意目标地址不带端口"
            echo -e
            ps aux | grep "gost -L" | grep -v grep
            echo -e
            read -p "开始端口: " start_port
            read -p "结束端口: " end_port
            read -p "目标地址: " ip_addr
            if [[ -z "$start_port" && -z "$end_port" && -z "$ip_addr" ]]; then
                continue  # 没有实际输入内容则跳过后面代码返回主循环
            fi
            # 精准匹配进程信息并杀死进程终止运行
            ps aux | grep "gost -L tcp://:${start_port}-${end_port}/${ip_addr}:${start_port}-${end_port}" | grep -v grep | awk '{print $2}' | xargs kill -9
            # 精准匹配删除对应的计划任务这样开机就不会再自启了
            sed -i "/gost -L tcp:\/\/:${start_port}-${end_port}\/${ip_addr}:${start_port}-${end_port}/d" /etc/crontab
            echo -e
            ps aux | grep "gost -L" | grep -v grep
            ;;
        0)
            clear
            exit 0
            ;;
        *)
            echo "错误选择..."
            ;;
    esac
}


# 主循环
while true; do
    show_menu
    execute_choice
    read -n 1
done

