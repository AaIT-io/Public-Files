#!/bin/bash


# GOST端口转发函数脚本
# 提前封装好方便后面调用


# GOST管理API统一账号密码,内网通讯
gost_api_auth="gost:jWQn7B5hn1bhEe3j"


# 函数: 查看本机GOST配置 / JSON格式 + 提取对齐排序
view_config() {
    curl -s -u "$gost_api_auth" "127.0.0.1:65535/api/config" | jq -r '.services[] | "\(.name) \(.addr) \(.forwarder.nodes[].addr)"' | sort -k1 | column -t
}


# 函数: 保存配置信息到文件 / YAML格式
save_config() {
    curl -s -X POST -H "Content-Type: application/json" \
    -u "$gost_api_auth" \
    "127.0.0.1:65535/api/config?format=yaml&path=/opt/gost/gost.yaml"
}


# 函数：创建端口转发
create_service() {
    local service_name="$1"       # 服务名称
    local service_port="$2"       # 监听端口
    local node_addr="$3"          # 转发目标

    # 使用 POST 请求创建服务
    curl -s -X POST -H "Content-Type: application/json" \
    -u "$gost_api_auth" \
    -d "{
        \"name\": \"$service_name\",
        \"addr\": \":${service_port}\",
        \"handler\": {\"type\": \"rtcp\"},
        \"listener\": {\"type\": \"rtcp\"},
        \"forwarder\": {
            \"nodes\": [{\"name\": \"node\", \"addr\": \"$node_addr\"}]
        }
    }" "127.0.0.1:65535/api/config/services"
}


# 函数：更新端口转发
update_service() {
    local service_name="$1"       # 服务名称
    local service_port="$2"       # 监听端口
    local node_addr="$3"          # 转发目标

    # 使用 PUT 请求更新服务
    curl -s -X PUT -H "Content-Type: application/json" \
    -u "$gost_api_auth" \
    -d "{
        \"name\": \"$service_name\",
        \"addr\": \":${service_port}\",
        \"handler\": {\"type\": \"rtcp\"},
        \"listener\": {\"type\": \"rtcp\"},
        \"forwarder\": {
            \"nodes\": [{\"name\": \"node\", \"addr\": \"$node_addr\"}]
        }
    }" "127.0.0.1:65535/api/config/services/$service_name"
}


# 函数：删除服务
delete_service() {
    local service_name="$1"          # 服务名称

    # 使用 DELETE 请求删除服务
    curl -s -X DELETE -u "$gost_api_auth" \
    "127.0.0.1:65535/api/config/services/$service_name"
}


# 加上这段就可以外部直接调用脚本特定函数
# ./t.sh view_config "100.64.0.xxx"
if [[ $# -gt 0 ]]; then
    "$@"
else
    echo "请提供函数名和参数"
fi

